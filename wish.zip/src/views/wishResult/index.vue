<template>
  <transition name="wish-result" appear>
    <div class="wish-result">
      <p class="back-btn" @click="toPath('/wish')"></p>
      <template v-for="item in itemList" :key="item.label">
        <transition :name="'wish-item' + item.label" appear>
          <div
            :class="'item-box wish-item' + item.label"
            :id="'item' + item.label"
          >
            <img class="item-image" :src="item.url" />
          </div>
        </transition>
        <transition :name="'wish-item-bg' + item.label" appear>
          <div
            v-if="item.star === 3"
            :class="'item-box-bg wish-item-bg' + item.label"
            :id="'bg' + item.label"
          >
            <div class="bg1-blue"></div>
            <div class="bg2-blue"></div>
            <div class="bg3-blue"></div>
          </div>
          <div
            v-else-if="item.star === 4"
            :class="'item-box-bg wish-item-bg' + item.label"
            :id="'bg' + item.label"
          >
            <div class="bg2-purple"></div>
            <div class="bg1-purple">
              <div class="bg1-purple-left"></div>
              <div class="bg1-purple-right"></div>
            </div>
          </div>
          <div
            v-else
            :class="'item-box-bg wish-item-bg' + item.label"
            :id="'bg' + item.label"
          >
            <div class="bg2-king"></div>
            <div class="bg1-king">
              <div class="bg1-king-1"></div>
              <div class="bg1-king-2"></div>
              <div class="bg1-king-3"></div>
              <div class="bg1-king-left"></div>
              <div class="bg1-king-right"></div>
            </div>
          </div>
        </transition>
      </template>
    </div>
  </transition>
  <!-- 从抽卡动画过渡 -->
  <div class="mask"></div>
  <!-- 进入页面前防点击遮罩 -->
  <div class="mask transparent" id="transparent"></div>
</template>

<script>
import { reactive, toRefs, onMounted, onUnmounted } from "vue";
import { useRouter } from "vue-router";
import { useStore } from "vuex";

export default {
  name: "WishResultView",
  setup() {
    const router = useRouter();
    const store = useStore();

    // js控制进入页面一段时间加一层透明遮罩，之后添加wish-item渐变效果，否则vue的transition标签和css的transition属性有冲突
    const t = setTimeout(() => {
      document
        .getElementsByClassName("wish-result")[0]
        .childNodes.forEach((item) => {
          if (item.localName === "div") {
            // TODO 换成类名检索会更好
            item.style.transition = "transform 0.2s ease";
          }
        });
      document.getElementById("transparent").style.zIndex = -100;
    }, 1200);

    let data = reactive({
      itemList: [],
    });
    //令人疑惑的影响，直接赋值后下面添加label和url的操作会影响到store.state.recentList
    data.itemList = JSON.parse(JSON.stringify(store.state.recentList));
    //按星级排序
    data.itemList.sort(function (a, b) {
      return b.star - a.star;
    });
    //label和url
    data.itemList.forEach((item, index) => {
      item.label = index + 1;
      item.url = require("../../assets/image/item/" + item.name + ".png");
    });
    console.log(
      "\t*********************本次抽卡数据*********************\n",
      JSON.parse(JSON.stringify(store.state.recentList))
    );
    
    const toPath = (url) => {
      router.push({ path: url });
    };

    onMounted(() => {
      // 单抽位置
      if (data.itemList.length === 1) {
        document.getElementById("item1").style.left = "46.3vw";
        document.getElementById("bg1").style.left = "46.6vw";
      }
      // 十抽位置
      else {
        data.itemList.forEach((item, index) => {
          document.getElementById("bg" + (index + 1)).style.left =
            12.85 + 7.5 * index + "vw";
        });
      }
    });

    onUnmounted(() => {
      clearTimeout(t); // 卸载时清除定时防止继续添加渐变样式
    });

    return {
      ...toRefs(data),
      toPath,
    };
  },
};
</script>

<style scoped lang="scss">
// 渐入遮罩
.mask {
  width: 100vw;
  height: 100vh;
  background-color: #000;
}
// 防点击透明遮罩
.transparent {
  position: absolute;
  top: 10vh;
  height: 90vh;
  background-color: rgba($color: #ffffff, $alpha: 0);
  z-index: 100;
}
// 页面背景样式
.wish-result {
  overflow: hidden;
  position: absolute;
  width: 100vw;
  height: 100vh;
  background-image: url("../../assets/image/wishResultBg.png");
  background-repeat: no-repeat;
  background-size: 100% 100%;
  // 返回按钮样式
  .back-btn {
    top: 1.8vh;
    right: 2.5vw;
    position: absolute;
    height: 5.4vh;
    width: 5.4vh;
    background-image: url("../../assets/image/icon-back.png");
    background-repeat: no-repeat;
    background-size: 100% 100%;
    border-radius: 2.7vh;
    transition: all 0.2s ease;
    &:hover {
      box-shadow: 0 0 10px #fff inset,
      0 0 5px rgba($color: #ffffff, $alpha: 0.7);
    }
    &:active {
      opacity: 0.8;
    }
  }
  // 抽卡物品通用样式 z-index防止背部特效穿模
  .item-box {
    z-index: 11; // test
    position: absolute;
    top: 22vh;
    background-color: rgba($color: #ffffff, $alpha: 0);
    box-sizing: border-box;
    border: 5px solid #fff inset;
    &:hover {
      transform: scale(1.06);
    }
    // 鼠标移入时背部特效一起放大
    &:hover + .item-box-bg {
      transform: scale(1.06);
    }
    // 抽卡物品图片样式
    .item-image {
      height: 56.8vh;
      width: 7.4vw;
      object-fit: fill;
    }
  }
  // 抽卡物品位置
  .wish-item1 {
    left: 12.55vw;
  }
  .wish-item2 {
    left: 20.05vw;
  }
  .wish-item3 {
    left: 27.55vw;
  }
  .wish-item4 {
    left: 35.05vw;
  }
  .wish-item5 {
    left: 42.55vw;
  }
  .wish-item6 {
    left: 50.05vw;
  }
  .wish-item7 {
    left: 57.55vw;
  }
  .wish-item8 {
    left: 65.05vw;
  }
  .wish-item9 {
    left: 72.55vw;
  }
  .wish-item10 {
    left: 80.05vw;
  }
  // 抽卡物品特效通用样式
  .item-box-bg {
    position: absolute;
    top: 23vh;
    height: 52vh;
    width: 6.8vw;
    div {
      position: absolute;
    }
    .bg1-blue {
      top: 0.3vh;
      height: 14vh;
      width: 0.5vw;
      left: 3.5vw;
      border-right: 0.2vw solid transparent;
      border-left: 0.2vw solid #fff;
      border-top: 20vh solid transparent;
      border-bottom: 20vh solid transparent;
      filter: drop-shadow(0 50px 4px #fff) drop-shadow(0 -50px 4px #fff)
        drop-shadow(0 50px 5px #2877ff) drop-shadow(0 -50px 5px #2877ff); // test
    }
    .bg2-blue {
      top: 0.3vh;
      height: 14vh;
      width: 0.5vw;
      right: 3.5vw;
      border-right: 0.2vw solid #fff;
      border-left: 0.2vw solid transparent;
      border-top: 20vh solid transparent;
      border-bottom: 20vh solid transparent;
      filter: drop-shadow(0 50px 4px #fff) drop-shadow(0 -50px 4px #fff)
        drop-shadow(0 50px 5px #2877ff) drop-shadow(0 -50px 5px #2877ff); // test
    }
    .bg3-blue {
      top: 0.3vh;
      height: 54vh;
      width: 6.8vw;
      border-radius: 50%;
      background-color: #fff;
      filter: drop-shadow(0 0 5px #fff) drop-shadow(0 0 7px #2e7bff)
        drop-shadow(0 0 16px #3a82ff);
    }
    .bg1-purple {
      filter: drop-shadow(0 20px 3px #ccc0fb) drop-shadow(0 -20px 3px #ccc0fb)
        drop-shadow(0 30px 6px #ccc0fb) drop-shadow(0 -30px 6px #ccc0fb)
        drop-shadow(0 60px 15px #7755ff) drop-shadow(0 -60px 15px #7755ff);

      div {
        top: -0.1vh;
        height: 15vh;
        width: 0.5vw;
        border-top: 20vh solid transparent;
        border-bottom: 20vh solid transparent;
      }
      .bg1-purple-right {
        left: 3.35vw;
        border-right: 2vw solid transparent;
        border-left: 2vw solid #fff;
      }
      .bg1-purple-left {
        left: -1.05vw;
        border-right: 2vw solid #fff;
        border-left: 2vw solid transparent;
      }
    }
    .bg2-purple {
      top: 0.3vh;
      height: 54vh;
      width: 6.8vw;
      border-radius: 50%;
      background-color: #fff;
      filter: drop-shadow(0 10px 7px #ccc0fb) drop-shadow(0 -10px 7px #ccc0fb)
        drop-shadow(0 0 10px #fff);
    }
    .bg1-king {
      filter: drop-shadow(0 70px 8px #ffed90) drop-shadow(0 -70px 8px #ffed90)
        drop-shadow(0 70px 25px #ffb855) drop-shadow(0 -70px 25px #ffb855);

      div {
        top: -0.1vh;
        height: 15vh;
        width: 0.5vw;
        border-top: 20vh solid transparent;
        border-bottom: 20vh solid transparent;
      }
      .bg1-king-1 {
        top: 6.4vh;
        left: -1.2vw;
        height: 36vh;
        border-top: 2vh solid transparent;
        border-bottom: 2vh solid transparent;
        border-right: 1vw solid #fff;
        border-left: 1vw solid transparent;
      }
      .bg1-king-2 {
        top: 1.8vh;
        left: 1vw;
        height: 46vh;
        border-top: 2vh solid transparent;
        border-bottom: 2vh solid transparent;
        border-right: 0.5vw solid #fff;
        border-left: 0.5vw solid transparent;
      }
      .bg1-king-3 {
        top: 3.4vh;
        left: 4vw;
        height: 44vh;
        border-top: 2vh solid transparent;
        border-bottom: 2vh solid transparent;
        border-right: 1vw solid transparent;
        border-left: 1vw solid #fff;
      }
      .bg1-king-right {
        left: 3.35vw;
        border-top: 20vh solid transparent;
        border-bottom: 20vh solid transparent;
        border-right: 2vw solid transparent;
        border-left: 2vw solid #fff;
      }
      .bg1-king-left {
        left: -1.05vw;
        border-top: 20vh solid transparent;
        border-bottom: 20vh solid transparent;
        border-right: 2vw solid #fff;
        border-left: 2vw solid transparent;
      }
    }
    .bg2-king {
      top: 0.3vh;
      height: 54vh;
      width: 6.8vw;
      border-radius: 50%;
      background-color: #fff;
      filter: drop-shadow(0 10px 7px #ffe979) drop-shadow(0 -10px 7px #ffe979)
        drop-shadow(0 0 10px #ffb855) drop-shadow(0 0 10px #ffb855);
    }
  }
  // 抽卡物品特效位置和颜色 z-index设置左侧（星级高）的物品颜色在上层
  .wish-item-bg1 {
    z-index: 10;
  }
  .wish-item-bg2 {
    z-index: 9;
  }
  .wish-item-bg3 {
    z-index: 8;
  }
  .wish-item-bg4 {
    z-index: 7;
  }
  .wish-item-bg5 {
    z-index: 6;
  }
  .wish-item-bg6 {
    z-index: 5;
  }
  .wish-item-bg7 {
    z-index: 4;
  }
  .wish-item-bg8 {
    z-index: 3;
  }
  .wish-item-bg9 {
    z-index: 2;
  }
  .wish-item-bg10 {
    z-index: 1;
  }
}
/** vue transition标签渐入渐出样式 start */
// 进入页面时渐入
.wish-result-enter-from {
  opacity: 0;
}
.wish-result-enter-active {
  transition: opacity 0.9s ease;
}
// 物品载入渐入
.wish-item1-enter-from,
.wish-item2-enter-from,
.wish-item3-enter-from,
.wish-item4-enter-from,
.wish-item5-enter-from,
.wish-item6-enter-from,
.wish-item7-enter-from,
.wish-item8-enter-from,
.wish-item9-enter-from,
.wish-item10-enter-from {
  opacity: 0;
  transform: translate(30vw);
}
.wish-item1-enter-active {
  transition: all 0.6s ease-out;
}
.wish-item2-enter-active {
  transition: all 0.6s ease-out 0.07s;
}
.wish-item3-enter-active {
  transition: all 0.6s ease-out 0.14s;
}
.wish-item4-enter-active {
  transition: all 0.6s ease-out 0.21s;
}
.wish-item5-enter-active {
  transition: all 0.6s ease-out 0.28s;
}
.wish-item6-enter-active {
  transition: all 0.6s ease-out 0.35s;
}
.wish-item7-enter-active {
  transition: all 0.6s ease-out 0.42s;
}
.wish-item8-enter-active {
  transition: all 0.6s ease-out 0.49s;
}
.wish-item9-enter-active {
  transition: all 0.6s ease-out 0.56s;
}
.wish-item10-enter-active {
  transition: all 0.6s ease-out 0.63s;
}

.wish-item-bg1-enter-from,
.wish-item-bg2-enter-from,
.wish-item-bg3-enter-from,
.wish-item-bg4-enter-from,
.wish-item-bg5-enter-from,
.wish-item-bg6-enter-from,
.wish-item-bg7-enter-from,
.wish-item-bg8-enter-from,
.wish-item-bg9-enter-from,
.wish-item-bg10-enter-from {
  opacity: 0;
  // transform: translate(1vw);
}
.wish-item-bg1-enter-active {
  transition: opacity 0.2s ease-out 0.5s;
  // transition: 0.6s ease-out;
}
.wish-item-bg2-enter-active {
  transition: opacity 0.2s ease-out 0.57s;
}
.wish-item-bg3-enter-active {
  transition: opacity 0.2s ease-out 0.64s;
}
.wish-item-bg4-enter-active {
  transition: opacity 0.2s ease-out 0.71s;
}
.wish-item-bg5-enter-active {
  transition: opacity 0.2s ease-out 0.78s;
}
.wish-item-bg6-enter-active {
  transition: opacity 0.2s ease-out 0.85s;
}
.wish-item-bg7-enter-active {
  transition: opacity 0.2s ease-out 0.92s;
}
.wish-item-bg8-enter-active {
  transition: opacity 0.2s ease-out 0.99s;
}
.wish-item-bg9-enter-active {
  transition: opacity 0.2s ease-out 1.06s;
}
.wish-item-bg10-enter-active {
  transition: opacity 0.2s ease-out 1.13s;
}
/** vue transition标签渐入渐出样式 end */
</style>
